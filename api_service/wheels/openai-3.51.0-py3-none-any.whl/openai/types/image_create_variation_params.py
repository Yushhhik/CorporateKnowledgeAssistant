# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from typing_extensions import Literal, Required, TypedDict

from .._types import FileTypes
from .image_model import ImageModel

__all__ = ["ImageCreateVariationParams"]


class ImageCreateVariationParams(TypedDict, total=False):
    image: Required[FileTypes]
    """The image to use as the basis for the variation(s).

    Must be a valid PNG file, less than 4MB, and square.
    """

    model: Union[str, ImageModel, None]
    """The legacy model used by the retired image variations endpoint.

    This endpoint no longer accepts requests.

    Deprecated values:

    - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
      gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
    - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
      image model instead.
    """

    n: Optional[int]
    """The number of images to generate. Must be between 1 and 10."""

    response_format: Optional[Literal["url", "b64_json"]]
    """The format in which the generated images are returned.

    Must be one of `url` or `b64_json`. URLs are only valid for 60 minutes after the
    image has been generated.
    """

    size: Optional[Literal["256x256", "512x512", "1024x1024"]]
    """The size of the generated images.

    Must be one of `256x256`, `512x512`, or `1024x1024`.
    """

    user: str
    """
    A unique identifier representing your end-user, which can help OpenAI to monitor
    and detect abuse.
    [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).
    """
